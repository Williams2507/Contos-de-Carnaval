import React, { useState } from 'react';
import { 
  BookOpen, 
  ChevronLeft, 
  Menu, 
  X,
  Calendar,
  User,
  Clock,
  ArrowRight,
  Search,
  Share2,
  Printer
} from 'lucide-react';
import senaiLogo from 'figma:asset/47f2f038aeb182c5bdff3505338d442b04cc379a.png';


type Story = {
  id: string;
  title: string;
  description: string;
  author: string;
  readTime: string;
  content: string;
  category: string;
};


const STORIES: Story[] = [
  {
    id: '1',
    title: 'O Baile do Rei Momo',
    description: 'Um conto sobre a elegância e a magia dos antigos bailes de carnaval no Rio de Janeiro.',
    author: 'Machado de Assis (Adaptado)',
    readTime: '5 min',
    category: 'Clássicos',
    content: `
      <p>Era uma vez, no antigo Rio de Janeiro, um baile que prometia ser o maior de todos os tempos. O Rei Momo, figura lendária de alegria e fartura, havia decretado que naquela noite nenhuma tristeza seria permitida nos salões do grande teatro.</p>
      <p>As damas vestiam sedas coloridas importadas da Europa, e os cavalheiros, mesmo sob o calor tropical, mantinham a elegância em seus fraques, logo substituídos por fantasias leves de pierrôs e dominós.</p>
      <p>No centro do salão, uma orquestra tocava polcas e lundus, ritmos que faziam os pés se moverem sozinhos. Diziam que a música tinha o poder de curar qualquer dor de cotovelo.</p>
      <p>Entre os convidados, estava um jovem poeta chamado Bento. Bento era tímido e observava tudo de um canto, segurando sua taça de refresco. Ele procurava inspiração para seus versos, mas o barulho da festa o atordoava.</p>
      <p>Foi então que ele viu uma máscara prateada cruzar o salão. Não viu o rosto, apenas os olhos que brilhavam como estrelas por trás do disfarce. Bento, movido por uma coragem repentina, decidiu seguir a figura misteriosa.</p>
      <p>Eles dançaram a noite toda sem trocar uma palavra. A linguagem era apenas o ritmo, o toque das mãos enluvadas e os olhares cúmplices.</p>
      <p>Quando o relógio marcou meia-noite e a quarta-feira de cinzas se anunciava, a dama prateada entregou a Bento uma flor de papel crepom e desapareceu na multidão.</p>
      <p>Bento nunca soube quem ela era, mas escreveu os poemas mais lindos de sua vida inspirado naquela única noite de folia eterna.</p>
    `
  },
  {
    id: '2',
    title: 'A Cidade das Máscaras Vivas',
    description: 'Uma lenda veneziana sobre identidade e a verdadeira face por trás da fantasia.',
    author: 'Lenda Veneziana',
    readTime: '4 min',
    category: 'Fantasia',
    content: `
      <p>Existe uma lenda sobre uma cidade onde o Carnaval nunca termina. Lá, as máscaras não são feitas de papel ou plástico, mas de pura magia. Quando alguém coloca uma máscara nessa cidade, ela se torna o personagem que escolheu.</p>
      <p>Se você escolhe a máscara do valente cavaleiro, ganha força e coragem. Se escolhe a da sábia coruja, passa a conhecer todos os segredos do mundo.</p>
      <p>Um dia, um viajante chamado Marco chegou a essa cidade. Ele estava cansado de ser quem era: um simples alfaiate com uma vida monótona.</p>
      <p>Ele entrou na loja do Mestre Mascarer e pediu: "Quero a máscara do Rei". O Mestre sorriu enigmaticamente e lhe entregou uma máscara dourada, pesada e majestosa.</p>
      <p>Marco colocou a máscara e, imediatamente, sua postura mudou. As pessoas na rua se curvavam, ofereciam banquetes e elogios.</p>
      <p>Por dias, Marco viveu no luxo e no poder. Mas logo percebeu algo terrível: a máscara não saía mais. Ele tentava puxar, mas ela havia se fundido ao seu rosto.</p>
      <p>Ele não podia mais sentir o vento na pele, nem o beijo de sua amada, nem o gosto das frutas. Era um Rei, mas era prisioneiro de sua própria escolha.</p>
      <p>Desesperado, voltou ao Mestre. "Como tiro isso?", implorou.</p>
      <p>"Para tirar a máscara da vaidade", disse o Mestre, "você deve encontrar a sua verdadeira face".</p>
      <p>Marco passou anos servindo aos pobres e ajudando os outros, esquecendo-se de sua realeza. Um dia, ao enxugar o suor da testa após um dia de trabalho, a máscara dourada caiu no chão, revelando seu rosto de alfaiate, agora marcado por rugas de sorrisos verdadeiros.</p>
    `
  },
  {
    id: '3',
    title: 'O Samba da Reconciliação',
    description: 'Duas famílias rivais e um desfile que mudou a história de uma comunidade.',
    author: 'Lima Barreto (Inspirado)',
    readTime: '6 min',
    category: 'Drama',
    content: `
      <p>No morro da Mangueira, duas famílias vizinhas não se falavam há gerações. Os Silvas e os Santos brigavam por tudo: a altura do muro, o barulho do rádio, até a cor da tinta do portão.</p>
      <p>Mas o Carnaval tem uma força que desafia qualquer rixa antiga. Naquele ano, a escola de samba do bairro decidiu fazer um enredo sobre a "União".</p>
      <p>O destino, sempre irônico, colocou Julinho Silva e Mariana Santos como par de Mestre-Sala e Porta-Bandeira. Eles protestaram, gritaram, ameaçaram sair da escola.</p>
      <p>Mas o carnavalesco foi firme: "Ou dançam juntos, ou a escola não desfila". Pelo amor ao pavilhão, eles aceitaram, mas prometeram não trocar um olhar sequer nos ensaios.</p>
      <p>Os primeiros ensaios foram desastrosos. Eles pisavam no pé um do outro, giravam para lados opostos. A comunidade olhava preocupada.</p>
      <p>Mas conforme o samba-enredo entrava no coração, algo mudava. A letra falava de perdoar, de abraçar, de somar forças.</p>
      <p>Na noite do desfile oficial, na Sapucaí iluminada, a mágica aconteceu. Quando a bateria fez o recuo e o surdo de primeira marcou o compasso, Julinho olhou para Mariana.</p>
      <p>Não viu a inimiga, viu a parceira que carregava o peso da bandeira que ambos amavam.</p>
      <p>Eles rodopiaram como nunca. O bailado foi tão perfeito, tão cheio de sincronia e emoção, que o público levantou nas arquibancadas.</p>
      <p>Tiraram nota 10 de todos os jurados. No final da apoteose, abraçados e chorando de alegria, as famílias Silva e Santos perceberam que o muro que os separava era muito menor que a avenida que os unia.</p>
    `
  },
  {
    id: '4',
    title: 'A Origem do Confete',
    description: 'Curiosidades históricas sobre como surgiram os confetes nos carnavais de rua.',
    author: 'História Popular',
    readTime: '3 min',
    category: 'Curiosidades',
    content: `
      <p>Você sabe de onde vem o confete? Muitos acham que sempre foi papel colorido, mas a história conta algo diferente.</p>
      <p>Dizem que na Itália antiga, durante os carnavais de Veneza, os nobres jogavam sementes de coentro cobertas de açúcar para a multidão. Eram doces, chamados "confetti".</p>
      <p>Mas jogar doces duros podia machucar! Então, com o tempo, as pessoas começaram a jogar bolinhas de gesso, o que fazia uma sujeira branca e poeirenta em toda a cidade.</p>
      <p>Foi só muito tempo depois, em um dia ensolarado em Milão, que um homem teve uma ideia melhor.</p>
      <p>Esse homem trabalhava em uma criação de bicho-da-seda. Para os bichinhos dormirem, ele usava papéis furadinhos. Sobravam milhares de pequenos círculos de papel colorido que iriam para o lixo.</p>
      <p>"E se...", pensou ele.</p>
      <p>Ele encheu um saco com esses restinhos de papel e levou para o desfile. Quando a carruagem passou, ele jogou a nuvem colorida para o alto. O papel voou leve, dançou com o vento e caiu suavemente sobre os foliões.</p>
      <p>Foi um sucesso instantâneo! Era barato, colorido e não machucava ninguém. Logo, o mundo inteiro estava cortando papel para jogar para o alto.</p>
      <p>Então, da próxima vez que você jogar um punhado de confete, lembre-se: você está jogando para o alto pequenos pedaços de alegria inventados para celebrar a vida.</p>
    `
  },
  {
    id: '5',
    title: 'O Bloco dos Sonhos Esquecidos',
    description: 'Um conto poético sobre onde vão parar os nossos sonhos de infância durante a folia.',
    author: 'Conto Fantástico',
    readTime: '4 min',
    category: 'Fantasia',
    content: `
      <p>Dizem que quando a gente acorda e esquece um sonho bom, ele não desaparece. Ele vai para uma rua secreta, em uma cidade invisível, esperar pelo Carnaval.</p>
      <p>Nessa rua, existe o Bloco dos Sonhos Esquecidos. É o bloco mais bonito que ninguém nunca viu.</p>
      <p>Lá desfilam os desejos de voar, as vontades de ser astronauta que tivemos na infância, e os amores de verão que duraram apenas uma sesta.</p>
      <p>As fantasias são feitas de neblina e raio de sol. A música não tem som, mas faz o coração vibrar.</p>
      <p>Uma vez por ano, diz a lenda, esse bloco atravessa o mundo real. É aquele momento no meio da folia em que você sente uma alegria repentina sem motivo, ou lembra de um cheiro da infância.</p>
      <p>É o Bloco passando por dentro de você. Ele nos lembra que nenhum sonho é perdido de verdade, eles apenas ficam guardados esperando a hora certa de sambar.</p>
      <p>Por isso, se sentir um arrepio bom durante o Carnaval, feche os olhos e sorria. É o seu sonho esquecido mandando um "oi" e pedindo para você não deixar a fantasia acabar.</p>
    `
  }
];


function Header({ onNavigate, currentPage }: { onNavigate: (page: string) => void, currentPage: string }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="flex flex-col w-full shadow-sm sticky top-0 z-50">
      <div className="bg-white py-4 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <div 
            className="flex items-center gap-4 cursor-pointer" 
            onClick={() => onNavigate('home')}
          >
            <img src={senaiLogo} alt="SENAI" className="h-10 md:h-12 w-auto object-contain" />
            <div className="h-8 w-px bg-gray-300 mx-2 hidden sm:block"></div>
            <div className="hidden sm:flex flex-col">
              <span className="text-sm font-bold text-[#004587] uppercase tracking-wide">
                Contos de Carnaval
              </span>
              <span className="text-[10px] text-gray-500 uppercase tracking-widest">
                SENAI CETAF AJU
              </span>
            </div>
          </div>
          
          <button 
            className="md:hidden p-2 text-[#004587]"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </div>

      <div className="h-1 bg-[#E35205] w-full"></div>

      {mobileMenuOpen && (
        <div className="md:hidden bg-[#004587] border-t border-blue-800 animate-in slide-in-from-top-2">
          <div className="px-4 py-4 space-y-2">
            <button 
              onClick={() => { onNavigate('home'); setMobileMenuOpen(false); }}
              className="block w-full text-left px-3 py-3 text-sm font-bold text-white uppercase hover:bg-[#E35205] rounded-md transition-colors"
            >
              Início
            </button>
            <button 
              onClick={() => { 
                onNavigate('home'); 
                setMobileMenuOpen(false);
                setTimeout(() => document.getElementById('stories')?.scrollIntoView({ behavior: 'smooth' }), 100);
              }}
              className="block w-full text-left px-3 py-3 text-sm font-bold text-white uppercase hover:bg-[#E35205] rounded-md transition-colors"
            >
              Contos
            </button>
          </div>
        </div>
      )}
    </header>
  );
}

function Hero({ onCtaClick }: { onCtaClick: () => void }) {
  return (
    <div className="bg-[#004587] relative overflow-hidden">

      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-[#003366] to-transparent opacity-50 skew-x-12 transform translate-x-20"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32 relative z-10">
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1 text-white text-center md:text-left">
            <div className="inline-block mb-6 px-4 py-1 bg-[#E35205] text-white text-xs font-bold uppercase tracking-widest rounded-full shadow-lg">
              SENAI CETAF AJU
            </div>
            <h1 className="text-5xl md:text-6xl font-black text-white mb-6 tracking-tight leading-tight">
              CONTOS DE <br />
              <span className="text-[#E35205] drop-shadow-sm">CARNAVAL</span>
            </h1>
            <p className="text-xl md:text-2xl text-blue-100 mb-10 leading-relaxed font-light max-w-2xl">
              Cultura, tradição e leitura. Descubra histórias fascinantes em nosso acervo digital exclusivo.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <button 
                onClick={onCtaClick}
                className="inline-flex justify-center items-center px-10 py-4 border-2 border-white text-base font-bold rounded-full text-[#004587] bg-white hover:bg-gray-100 hover:scale-105 transition-all shadow-lg uppercase tracking-wide"
              >
                Acessar Acervo
                <ArrowRight size={20} className="ml-2" />
              </button>
            </div>
          </div>
          
          <div className="flex-1 flex justify-center md:justify-end">
             <div className="relative">
               <div className="absolute inset-0 bg-white/20 rounded-full blur-3xl"></div>
               <BookOpen size={240} className="text-white/90 relative z-10 drop-shadow-2xl rotate-[-5deg]" strokeWidth={1} />
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StoryCard({ story, onClick }: { story: Story, onClick: () => void }) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 hover:border-[#004587] hover:shadow-xl transition-all duration-300 flex flex-col h-full group overflow-hidden">
      <div className="h-2 w-full bg-gradient-to-r from-[#004587] to-[#2A6AC7]"></div>
      <div className="p-8 flex-grow">
        <div className="flex justify-between items-start mb-6">
          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-50 text-[#004587]">
            {story.category}
          </span>
        </div>
        
        <h3 className="text-2xl font-bold text-slate-900 mb-4 group-hover:text-[#004587] transition-colors leading-tight">
          {story.title}
        </h3>
        
        <p className="text-slate-600 text-sm leading-relaxed line-clamp-3 mb-6 font-medium">
          {story.description}
        </p>
        
        <div className="flex items-center text-sm font-semibold text-gray-500 pt-4 border-t border-gray-100">
          <User size={16} className="mr-2 text-[#E35205]" />
          <span className="truncate uppercase text-xs tracking-wide">{story.author}</span>
        </div>
      </div>
      
      <div className="px-8 py-5 bg-gray-50 flex justify-between items-center group-hover:bg-[#004587] group-hover:text-white transition-colors duration-300 cursor-pointer" onClick={onClick}>
        <span className="text-xs font-bold uppercase tracking-widest text-gray-500 group-hover:text-blue-200">Ler agora</span>
        <div className="h-8 w-8 rounded-full bg-white flex items-center justify-center text-[#004587] shadow-sm transform group-hover:translate-x-1 transition-transform">
          <ChevronLeft size={16} className="rotate-180" />
        </div>
      </div>
    </div>
  );
}

function ReadingView({ story, onBack }: { story: Story, onBack: () => void }) {
  return (
    <div className="min-h-screen bg-gray-100 animate-in fade-in duration-300 pb-20">
      <div className="bg-[#004587] text-white sticky top-0 z-40 shadow-lg">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <button 
            onClick={onBack}
            className="flex items-center text-sm font-bold uppercase tracking-wide hover:text-[#E35205] transition-colors"
          >
            <ChevronLeft size={20} className="mr-1" />
            Voltar
          </button>
          <div className="flex items-center gap-4">
             <button className="text-white/70 hover:text-white" title="Compartilhar">
               <Share2 size={18} />
             </button>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-8">
        <article className="bg-white p-8 md:p-16 rounded-sm shadow-sm border border-gray-200 print:shadow-none print:border-none">
          <header className="mb-12 text-center border-b border-gray-100 pb-12">
            <span className="text-[#E35205] font-bold uppercase tracking-widest text-xs mb-4 block">
              {story.category}
            </span>
            <h1 className="text-3xl md:text-5xl font-serif font-bold text-[#004587] mb-6 tracking-tight leading-tight">
              {story.title}
            </h1>
            <div className="flex flex-wrap items-center justify-center gap-6 text-xs font-bold uppercase tracking-wide text-gray-400">
              <span className="flex items-center">
                <User size={14} className="mr-2 text-gray-300" />
                {story.author}
              </span>
            </div>
          </header>

          <div 
            className="prose prose-lg prose-slate max-w-none font-serif leading-loose text-slate-800 text-justify"
            dangerouslySetInnerHTML={{ __html: story.content }}
          />

          <div className="mt-16 pt-10 border-t border-gray-100 flex justify-center print:hidden">
            <button 
              onClick={onBack}
              className="inline-flex items-center px-8 py-3 border border-gray-300 shadow-sm text-sm font-bold uppercase tracking-wide rounded-full text-gray-600 bg-white hover:bg-gray-50 transition-all"
            >
              <ChevronLeft size={18} className="mr-2" />
              Voltar ao Acervo
            </button>
          </div>
        </article>
      </div>
    </div>
  );
}

function Footer() {
  return (
    <footer className="bg-[#004587] text-white pt-16 pb-8 border-t-4 border-[#E35205]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start gap-12 mb-12">
          
          <div className="flex flex-col items-start max-w-sm">
            <img src={senaiLogo} alt="SENAI Logo" className="h-10 mb-6 brightness-0 invert" />
            <h3 className="text-2xl font-black mb-4 uppercase tracking-tighter">Contos de Carnaval</h3>
            <p className="text-blue-200 text-sm leading-relaxed">
              Iniciativa educacional do SENAI CETAF AJU para promover a leitura, a cultura e a tradição brasileira através da tecnologia.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-12">
            <div>
              <ul className="space-y-3 text-sm text-blue-200">
              </ul>
            </div>
            
            <div>
              <ul className="space-y-3 text-sm text-blue-200">
              </ul>
            </div>

            <div>
              <ul className="space-y-3 text-sm text-blue-200">
                <li><span className="block text-white font-bold">CETAF AJU</span></li>
                <li>Aracaju - SE</li>
                <li>faleconosco@senai.br</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="border-t border-blue-800 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-blue-300">
          <p>© 2026 Serviço Nacional de Aprendizagem Industrial - Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}


export default function App() {
  const [activeStory, setActiveStory] = useState<Story | null>(null);
  
  const handleReadStory = (story: Story) => {
    setActiveStory(story);
    window.scrollTo(0, 0);
  };

  const handleBack = () => {
    setActiveStory(null);
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 selection:bg-[#E35205] selection:text-white flex flex-col">
      <Header 
        onNavigate={(page) => {
          if (page === 'home') handleBack();
        }} 
        currentPage={activeStory ? 'reading' : 'home'}
      />
      
      <main className="flex-grow">
        {activeStory ? (
          <ReadingView story={activeStory} onBack={handleBack} />
        ) : (
          <>
            <Hero onCtaClick={() => document.getElementById('stories')?.scrollIntoView({ behavior: 'smooth' })} />
            
            <div className="h-4 bg-gradient-to-r from-[#004587] via-[#E35205] to-[#004587]"></div>

            <section id="stories" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
              <div className="text-center mb-16">
                <span className="text-[#E35205] font-bold uppercase tracking-widest text-xs mb-2 block">Biblioteca Digital</span>
                <h2 className="text-4xl font-black text-[#004587] mb-4 uppercase">
                  Nossos Contos
                </h2>
                <div className="w-24 h-1.5 bg-[#E35205] mx-auto rounded-full"></div>
                <p className="mt-6 text-slate-500 max-w-2xl mx-auto text-lg">
                  Navegue pela nossa seleção especial de histórias carnavalescas, lendas e contos populares.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
                {STORIES.map((story) => (
                  <StoryCard 
                    key={story.id} 
                    story={story} 
                    onClick={() => handleReadStory(story)} 
                  />
                ))}
              </div>
            </section>
          </>
        )}
      </main>

      <Footer />
    </div>
  );
}
